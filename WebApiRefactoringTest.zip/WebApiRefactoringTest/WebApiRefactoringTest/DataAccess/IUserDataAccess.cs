﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiRefactoringTest.Models;

namespace WebApiRefactoringTest.DataAccess
{
    public interface IUserDataAccess
    {
        void AddUser(User user);
    }
}
