﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApiRefactoringTest.DataAccess;
using WebApiRefactoringTest.Models;

namespace WebApiRefactoringTest.DataAccess
{
    public class UserDataAccessProxy : IUserDataAccess
    {
        public void AddUser(User user)
        {
            UserDataAccess.AddUser(user);
        }
    }
}
