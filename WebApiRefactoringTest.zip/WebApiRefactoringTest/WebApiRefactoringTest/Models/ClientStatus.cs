﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiRefactoringTest.Models
{
    public enum ClientStatus
    {
        Gold = 1,
        Platinum = 2,
        Titanium = 3
    }
}
